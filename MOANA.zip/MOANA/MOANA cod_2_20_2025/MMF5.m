%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function Obj = MMF5(x)
% 1<=x1<=3    -1<=x2<=3
   
   Obj = zeros(2,1);
    if x(2)>1
        x(2)=x(2)-2;
    end
    Obj(1)      = abs(x(1)-2);             
    Obj(2)     = 1.0 - sqrt( abs(x(1)-2)) + 2.0*( x(2)-sin(6*pi* abs(x(1)-2)+pi)).^2;
end