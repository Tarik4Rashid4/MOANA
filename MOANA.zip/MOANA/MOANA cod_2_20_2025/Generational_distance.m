%{ 


%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012


C. M. Rahman and T. A. Rashid (2020), A new evolutionary algorithm: Learner performance based behavior algorithm, 
Egyptian Informatics Journal, https://doi.org/10.1016/j.eij.2020.08.003

Rahman, C.M., Rashid, T.A., Ahmed, A.M., Seyedali Mirjalili (2022) Multi-objective learner performance-based behavior algorithm with five multi-objective real-world engineering problems. 
Neural Comput & Applic . https://doi.org/10.1007/s00521-021-06811-z

Chnoor M. Rahman, Tarik A. Rashid, Abeer Alsadoon, Nebojsa Bacanin, Polla Fattah, Seyedali Mirjalili . A survey on dragonfly algorithm and its applications in engineering. 
Evol. Intel. (2021).https://doi.org/10.1007/s12065-021-00659-x

Chnoor M. Rahman and Tarik A. Rashid (2019). Dragonfly Algorithm and Its Applications in Applied Science Survey, Computational Intelligence and Neuroscience, Hindawi. 
Volume 2019, Article ID 9293617, 21 pages. https://doi.org/10.1155/2019/9293617
%}

function GD=Generational_distance(Pareto_Front,Factual)

row=size(Factual,1);

total_distance=0;
for i=1:size(Pareto_Front,1)
    D1=repmat(Pareto_Front(i,:),row,1);
    D2=D1-Factual;
    for j=1:row
        D3(j)=norm(D2(j,:));        
    end
    Distance=min(D3);
    total_distance = total_distance + (Distance^2);
end

GD=sqrt(((1/size(Pareto_Front,1))*total_distance));

