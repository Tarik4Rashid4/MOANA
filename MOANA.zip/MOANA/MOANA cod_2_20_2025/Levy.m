
%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}

% Disclaimer 
% the Levy code taken from this work https://link.springer.com/article/10.1007/s00521-015-1920-1 
% The codes for this function have been taken from: 
% Levy exponent and coefficient
% For details, see Chapter 11 of the following book:
% Xin-She Yang, Nature-Inspired Optimization Algorithms, Elsevier, (2014).

function o=Levy(d) 
beta=3/2;
%Eq. (3.10) in this paper https://link.springer.com/article/10.1007/s00521-015-1920-1
% sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
% u=randn(1,d)*sigma;
% v=randn(1,d);
% step=u./abs(v).^(1/beta);
% % beta = 0.5;
sigma = (gamma(1 + beta) * sin((pi * beta) / 2) / (gamma((1 + beta) / 2) * beta * power(2, (beta - 1) / 2))) ^ (1 / beta);

 r1 = simpleRandom() * sigma;
r2 = simpleRandom();
levyFlight = (r1 / abs(r2) ^ (1 / beta)) * 0.01;

if levyFlight >= 1.0 || levyFlight <= -1.0
    o = Levy();
else
    o = levyFlight;
end

% Eq. (3.9) in this paper https://link.springer.com/article/10.1007/s00521-015-1920-1
% o=0.001*step;
end

function randomValue = simpleRandom()
    randomValue = -1 + (1 - (-1)) * rand();
    randomValue = 0.1 * randomValue;
end
