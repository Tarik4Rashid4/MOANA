%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function DrawObjectives(pop,rep, Functin_Name,reference_ps)

if size([pop.Fitness], 1) == 2
    fitness_function=[pop.Fitness];
    plot(fitness_function(1,:),fitness_function(2,:),'ko');
    hold on;
    
    plot(reference_ps(:,1) , reference_ps(:, 2), 'g.');
    hold on; 
    rep_costs=[rep.Fitness];
    plot(rep_costs(1,:),rep_costs(2,:),'r*');
    
    xlabel('1^{st} Objective');
    ylabel('2^{nd} Objective');
    title(['Benchmark  ' Functin_Name]);
    grid on;
    hold off;
elseif  size([pop.Fitness], 1) == 3
%     fitness_function=[pop.Fitness];
%     scatter3(fitness_function(1,:),fitness_function(2,:), fitness_function(3,:), 10,'ko');
    hold on;
    
    rep_costs=[rep.Fitness];
    scatter3(rep_costs(1,:),rep_costs(2,:),rep_costs(3,:),10, 'r*');
    title(['Benchmark  ' Functin_Name]);
    xlabel('1^{st} Objective');
    ylabel('2^{nd} Objective');
    zlabel('3^{rd} Objective');
    grid on;
    hold off;
% 
% hold on;
% 
% fitness_function=[pop.Fitness];
% 
% 
% [x, y] = meshgrid(fitness_function(1,:), fitness_function(2,:));
% z =meshgrid(fitness_function(3,:));
% figure;
% surf(x,y,z);
%     xlabel('1^{st} Objective');
%     ylabel('2^{nd} Objective');
%     zlabel('3^{rd} Objective');
%     shading intrep;
%   grid on;
%   hold off;
%   
end
set(gcf,'units','points','position',[10,10,720,550]);
end
% udate24-6-2024
%     
% %     fitness_function=[pop.Fitness];
% %     plot(fitness_function(1,:),fitness_function(2,:),'ko');
% %     hold on;
%     plot(reference_ps(:,1) , reference_ps(:, 2), 'g.');
%     hold on;
%     rep_costs=[rep.Fitness];
%     plot(rep_costs(1, :),rep_costs(2, :),'r*');
%     
%    
%     
%     xlabel('1^{st} Objective');
%     ylabel('2^{nd} Objective');
%     title(['Benchmark  ' Functin_Name]);
%     grid on;
%     hold off;
%     
% elseif  size([pop.Fitness], 1) == 3
%     fitness_function=[pop.Fitness];
%     scatter3(fitness_function(1,:),fitness_function(2,:), fitness_function(3,:), 10,'ko');
%     hold on;
%     
%     rep_costs=[rep.Fitness];
%     scatter3(rep_costs(1,:),rep_costs(2,:),rep_costs(3,:),10, 'r*');
%     title(['Benchmark  ' Functin_Name]);
%     xlabel('1^{st} Objective');
%     ylabel('2^{nd} Objective');
%     zlabel('3^{rd} Objective');
%     grid on;
%     hold off;
% % 

% end
% %set(gcf,'units','points','position',[10,10,720,550]);
% end



