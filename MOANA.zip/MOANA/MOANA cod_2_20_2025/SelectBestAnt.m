
%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function Best_Ant = SelectBestBee(Archive, Best_Ant_Selection_factor)

    % Grid Index of All Repository Members
    GI=[Archive.GridIndex];
    
    % Occupied Cells
    OC=unique(GI);
    
    % Number of Particles in Occupied Cells
    N=zeros(size(OC));
    for k=1:numel(OC)
        N(k)=numel(find(GI==OC(k)));
    end
    
    % Selection Probabilities
    P=exp(-Best_Ant_Selection_factor*N);
    P=P/sum(P);
    
    % Selected Cell Index
    sci=RouletteWheelSelection(P);
    
    % Selected Cell
    sc=OC(sci);
    
    % Selected Cell Members
    SCM=find(GI==sc);
    
    % Selected Member Index
    smi=randi([1 numel(SCM)]);
    
    % Selected Member
    sm=SCM(smi);
    
    % Leader
    Best_Ant=Archive(sm);

end