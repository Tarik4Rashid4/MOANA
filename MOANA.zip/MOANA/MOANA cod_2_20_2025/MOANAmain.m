
%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


cite as:

Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}



clc;
clear;
close all;


Functin_Name = 'ZDT1';
[Dimensions,Fitness_Function ,Upper_Bound, Lower_Bound] = Select_Functions(Functin_Name);
    reference_ps=load(['references/' Functin_Name '.pf']);
%  reference_ps=load('ZDT1.txt');
main_record = zeros(30:1);
for turn = 1:1
    disp(['Turn ' num2str(turn)]);
    %% MOANA Parameter Sets
    
    Iterations=100;           %  Number of Iterations
    Number_of_Ants =500;      % Population Size
    Archive_size=500;         % Repository Size
    Grid_Number = 7;          % Number of Grids per Dimension
    Best_Ant_Selection_factor = 2;
    Polynomial_Mutation_Rate = 1/0.5;
    Delete_Factor = 2;
    Inflation_rate = 0.1;
    Decision_Variabels_Size =[1 Dimensions];   % Size of Decision Variables Matrix
    
    %% Initialization
    
    Initail_Ant.Position=[];
    Initail_Ant.Fitness=[];
    Initail_Ant.IsDominated=[];
    Initail_Ant.GridIndex=[];
    Initail_Ant.GridSubIndex=[];
    Initail_Ant.Best.Position=[];
    Initail_Ant.Best.Fitness=[];

    Ants = repmat(Initail_Ant, Number_of_Ants,1);
    tempAnt = repmat(Initail_Ant,1,1);
    
    %% Distributing Artificial Worker Ants Randomly
    for i=1:Number_of_Ants
        if numel(Lower_Bound) == 1
            Ants(i).Position=unifrnd(Lower_Bound,Upper_Bound,Decision_Variabels_Size);
        elseif numel(Lower_Bound) == 2
            lower =  unifrnd(Lower_Bound(1),Lower_Bound(2));
            upper = unifrnd(Upper_Bound(1),Upper_Bound(2));
            Ants(i).Position = [lower  upper ];
            
        end
        
        Ants(i).Fitness=Fitness_Function(Ants(i).Position);
        Ants(i).Best.Position = Ants(i).Position;
        Ants(i).Best.Fitness = Ants(i).Fitness;
    end
    
    %% Locating Non_Dominated Solutions
    Ants=CheckDomination(Ants);
    archive=Ants(~[Ants.IsDominated]);
    Hypercube_Grid = GenerateGrid(archive,Grid_Number,Inflation_rate);
    
    for i=1:numel(archive)
        archive(i)=FindGridIndex(archive(i),Hypercube_Grid);
    end
    
    %% MOANA Algorithm
    IGD_Record = zeros(Iterations: 1);
    IGD_Record2=zeros(Iterations:1);
    for it=1:Iterations
        Pre_Ant=Ants(1);
        for i=1:Number_of_Ants
% %  Equations 3.6 & 3.7
            Best_Ant=SelectBestAnt(archive,Best_Ant_Selection_factor);         
             previousTendency = sqrt(sum(Pre_Ant.Position) -sum(Best_Ant.Position))^2 + (sum(Fitness_Function(Pre_Ant.Position))-sum(Fitness_Function(Best_Ant.Position)))^2;
             tendency = sqrt(sum(Ants(i).Position) -sum(Best_Ant.Position))^2 + (sum(Fitness_Function(Ants(i).Position))- sum(Fitness_Function(Best_Ant.Position)))^2;

        for d=1 : Dimensions
            x = Ants(i).Position(d);
            xb= Best_Ant.Position(d);
            xPre=Pre_Ant.Position(d);
           
            distance_from_best_ant = xb- x;
           
          % Generate a random number in [-1, 1] range (Levy Flight)
         r = Levy();
         rateOfChange=0;
         % Equation 3.3
         if x == xb
             rateOfChange = x * r;
         %  Equation 3.4
         elseif x == xPre
             rateOfChange = distance_from_best_ant * r;
         else
                      
         % Equation 3.2
         rateOfChange = r * (tendency / previousTendency) * distance_from_best_ant;
                
         end
         
if isinf(rateOfChange)
    rateOfChange = x * r;
end

% Equation 3.1
newPosition = x + rateOfChange;
newPosition = max(newPosition, min(Lower_Bound));
newPosition = min(newPosition, max(Upper_Bound));
      end

                tempAnt.Position(d) = newPosition;
         
            if Fitness_Function(tempAnt.Position) < Fitness_Function( Ants(i).Position)
                Ants(i).Position = tempAnt.Position;
               
                Ants(i).Fitness = Fitness_Function(Ants(i).Position);
            else
                for m=1 : Dimensions
                    clear tempAnt;
                    random = Levy();
                    x = Ants(i).Position(m);
                    ee = x+x*random;
                    
x = max(x, min(Lower_Bound));
x = min(x, max(Upper_Bound));

      end
           tempAnt.Position(m)= x;

                end
               
if Fitness_Function(tempAnt.Position) < Fitness_Function(Ants(i).Position)
    Ants(i).Position = tempAnt.Position;
        break;

end 
Ants(i).Position = max(Ants(i).Position, min(Lower_Bound));
Ants(i).Position = min(Ants(i).Position, max(Upper_Bound));
Ants(i).Fitness = Fitness_Function(Ants(i).Position);
        
            % Apply Polynomial Mutation
            Polynomial_Mutation=(1-(it-1)/(Iterations-1))^(Polynomial_Mutation_Rate);
            if rand < Polynomial_Mutation
                Mutated_Solution.Position = Mutate(Ants(i).Position,Polynomial_Mutation,Lower_Bound,Upper_Bound);
                Mutated_Solution.Fitness=Fitness_Function(Mutated_Solution.Position);
                if Dominates(Mutated_Solution,Ants(i))
                    Ants(i).Position=Mutated_Solution.Position;
                    Ants(i).Fitness=Mutated_Solution.Fitness;
                elseif Dominates(Ants(i),Mutated_Solution)
                    % Discard Mutated Solution
                else
                    if rand<0.5
                        Ants(i).Position=Mutated_Solution.Position;
                        Ants(i).Fitness=Mutated_Solution.Fitness;
                    end
                end
            end
            
            if Dominates(Ants(i),Ants(i).Best)
                Ants(i).Best.Position=Ants(i).Position;
                Ants(i).Best.Fitness=Ants(i).Fitness;
            elseif Dominates(Ants(i).Best,Ants(i))
                % Best ant still better than current ant
            else
                if rand < 0.5
                    Ants(i).Best.Position=Ants(i).Position;
                    Ants(i).Best.Fitness=Ants(i).Fitness;
                end
            end
            Pre_Ant=Ants(i);
    end
       % Add Non-Dominated Ants to Archive
    archive=[archive
        Ants(~[Ants.IsDominated])]; %#ok
    
    % Determine Domination of New Archive Members
    archive=CheckDomination(archive);
    
    % Keep only Non-Dminated Memebrs in the Archive
    archive=archive(~[archive.IsDominated]);
    
    % Update Grid
    Hyper_Queb_Grid = GenerateGrid(archive,Grid_Number,Inflation_rate);
    
    % Update Grid Indices
    for i=1:numel(archive)
        archive(i)=FindGridIndex(archive(i),Hyper_Queb_Grid);
    end
    
    % Check if Archive is Full
    if numel(archive)>Archive_size
        Extra=numel(archive)-Archive_size;
        for e=1:Extra
            archive=DeleteOneArchiveMemebr(archive,Delete_Factor);
        end  
    end
    
    % Draw Objectives on plot
    figure(1);
     DrawOObjectives(Ants,archive, Functin_Name,reference_ps);
      pause(0.000001);

         % Show Iteration Information///udateee
%%%upate steps update 24-6-2024
        optaind_ps_num =  numel(archive) ;%update 24-6-2024
    
    for  ops = 1 : optaind_ps_num %update 24-6-2024
        obtained_ps(ops, 1) = archive(ops).Fitness(1, 1);%update 24-6-2024
        obtained_ps(ops, 2) = archive(ops).Fitness(2, 1);%update 24-6-2024
    end
    
    IGD_Record(it) =    IGD_calculation(obtained_ps, reference_ps);
    disp(['Iteration ' num2str(it) ': Number of Rep Members = ' num2str(numel(archive))]);

    Euclidean_Distance=0;
    for f=1:numel(archive)
        Euclidean_Distance = Euclidean_Distance + sum((Fitness_Function(Best_Ant.Position) - Fitness_Function(archive(f).Position)).^ 2);
    end
    
    Euclidean_Distance =  sqrt(Euclidean_Distance);
    
    IGD_Record(it) = Euclidean_Distance/numel(archive);

    
       disp(['IGD  =  ' num2str( IGD_Record(it))]);
       
      
        %  disp(['IGD  =  ' num2str(igd)]);
   
    end
end
    
    % Show IGD Information
    
    mean = sum(IGD_Record)/Iterations;
    best = min(IGD_Record);
    worest = max(IGD_Record);
    std_IGD = std(IGD_Record);
    main_record(turn,1)=  mean;
    main_record(turn,2)=  best;
    main_record(turn,3)=  worest;
    disp(['avg IGD  =  ' num2str( mean)]);
    disp(['std IGD  =  ' num2str(std_IGD)]);
    disp(['best  =  ' num2str( best)]);
    disp(['worst  =  ' num2str( worest)]);
    if turn == 30
        figure(2);
        DrawObjectives(Ants,archive, Functin_Name);
   
    end

