%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function y=MMF12(x)
% 0<=x1<=1    0<=x2<=1
% Discontinuous PF
q=4;%
Alfa=2;%
 
 y=zeros(2,1);
 y(1)=x(1);%
%  g=1+10*x(2);%
%  g=2-exp(-((x(2)-0.2)/0.004).^2)-0.8*exp(-((x(2)-0.6)/0.4).^2);
num_of_peak=2;
 g=2-((sin(num_of_peak*pi.*x(2))).^6)*(exp(-2*log10(2).*((x(2)-0.1)/0.8).^2));
 h=1-(y(1)/g)^Alfa-(y(1)/g)*sin(2*pi*q*y(1));
 y(2)=g*h;
 
end
% Multi-objective Genetic Algorithms: Problem Difficulties and
%Construction of Test Problems  P15