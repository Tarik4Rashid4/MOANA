%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function y=MMF13(x)
% 0.1<=x1<=1.1    0.1<=x2<=1.1  0.1<=x3<=1.1
% 1global PS and 1 local PS, PSs are non-liner 


    g=2-exp(-2*log10(2)*((x(2)+sqrt(x(3))-0.1)/0.8).^2)*(sin(2*pi*(x(2)+sqrt(x(3)))))^6;
    y1=x(1);
    y2=g/x(1);
    y= [y1
         y2];
% %%
end

% Multi-objective Genetic Algorithms: Problem Difficulties and Construction of Test Problems
