%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function Obj = MMF6(Var)
% 1<=x1<=2    -1<=x2<=2
   
   Obj = zeros(2,1);
    if (Var(2)>-1&&Var(2)<=0)&&(((Var(1)>7/6&&Var(1)<=8/6))||(Var(1)>9/6&&Var(1)<=10/6)||(Var(1)>11/6&&Var(1)<=2))
      Var(2)=Var(2);
        elseif (Var(2)>-1&&Var(2)<=0)&&((Var(1)>2&&Var(1)<=13/6)||(Var(1)>14/6&&Var(1)<=15/6)||(Var(1)>16/6&&Var(1)<=17/6))
          Var(2)=Var(2);

        elseif (Var(2)>1&&Var(2)<=2)&&((Var(1)>1&&Var(1)<=7/6)||(Var(1)>4/3&&Var(1)<=3/2)||(Var(1)>5/3&&Var(1)<=11/6))
       Var(2)=Var(2)-1;
         

        elseif (Var(2)>1&&Var(2)<=2)&&((Var(1)>13/6&&Var(1)<=14/6)||(Var(1)>15/6&&Var(1)<=16/6)||(Var(1)>17/6&&Var(1)<=3))
        Var(2)=Var(2)-1;
        
        elseif (Var(2)>0&&Var(2)<=1)&&((Var(1)>1&&Var(1)<=7/6)||(Var(1)>4/3&&Var(1)<=3/2)||(Var(1)>5/3&&Var(1)<=11/6)||(Var(1)>13/6&&Var(1)<=14/6)||(Var(1)>15/6&&Var(1)<=16/6)||(Var(1)>17/6&&Var(1)<=3))
          Var(2)=Var(2);
 
        elseif (Var(2)>0&&Var(2)<=1)&&((Var(1)>7/6&&Var(1)<=8/6)||(Var(1)>9/6&&Var(1)<=10/6)||(Var(1)>11/6&&Var(1)<=2)||(Var(1)>2&&Var(1)<=13/6)||(Var(1)>14/6&&Var(1)<=15/6)||(Var(1)>16/6&&Var(1)<=17/6))
          Var(2)=Var(2)-1;
     end
         Obj(1)      = abs(Var(1)-2);             
         Obj(2)      = 1.0 - sqrt( abs(Var(1)-2)) + 2.0*( Var(2)-sin(6*pi* abs(Var(1)-2)+pi)).^2; 
end