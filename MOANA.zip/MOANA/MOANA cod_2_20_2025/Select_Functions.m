
%                                                                   %
%  Author and programmer: Jaza Mahmood abdullah                     %
%                                                                   %
%         e-Mail: jazamahmood@gmail.com                             %
%                 jaza.abdullah.univsul.edu.iq                      %
%                                                                   %
%                                                                   %
%                                                                   %
% this code is an implementation of this paper work                 %
%                                                                   %


function [dimensions,Fitness_Function,upper_bound, lower_bound] = Select_Functions(functin_name)
addpath(genpath('RMTP/'));
addpath(genpath('functionss/'));

switch functin_name
   case 'Test1'
        Fitness_Function = @Test1;
        lower_bound=0;
        upper_bound=2;
        dimensions=2;
   case 'Test2'
        Fitness_Function = @Test2;
        lower_bound=0;
        upper_bound=2;
        dimensions=2;
   case 'Test7'
        Fitness_Function = @Test7;
        lower_bound=0;
        upper_bound=2;
        dimensions=2;
   case 'Test11'
        Fitness_Function = @Test11;
        lower_bound=0;
        upper_bound=2;
        dimensions=2;
    case 'Test16'
        Fitness_Function = @Test16;
        lower_bound=0;
        upper_bound=1;
        dimensions=2; 
    case 'Test20'
        Fitness_Function = @Test20;
        lower_bound=0;
        upper_bound=1;
        dimensions=2; 
    case 'ZDT1'
        Fitness_Function = @ZDT;
        lower_bound=0;
        upper_bound=1;
        dimensions=2;

    case 'ZDT2'
        Fitness_Function = @ZTD2;
        lower_bound=0;
        upper_bound=1;
        dimensions=2;
        
     case 'ZDT4'
        Fitness_Function = @ZTD4;
        lower_bound=0;
        upper_bound=1;
        dimensions=2;
     case 'ZDT3'
        Fitness_Function = @ZDT3;
        lower_bound=0;
        upper_bound=1;
        dimensions=2;
      case 'ZDT5'
        Fitness_Function = @ZDT5;
        lower_bound=0;
        upper_bound=1;
        dimensions=2;
        
         case 'ZDT6'
        Fitness_Function = @ZDT6;
        lower_bound=0;
        upper_bound=1;
        dimensions=2;
         case 'MMF1'
        Fitness_Function = @MMF1;
        lower_bound= [-1, 1];
        upper_bound = [1, 3] ;
        dimensions=2;   
        
      case 'MMF2'
        Fitness_Function = @MMF2;
        lower_bound= [0, 1];
        upper_bound = [0, 2] ;
        dimensions=2;   
        
       case 'MMF3'
        Fitness_Function = @MMF3;
        lower_bound= [0, 1];
        upper_bound = [0, 1.5] ;
        dimensions=2;   
        
      case 'MMF4'
        Fitness_Function = @MMF4;
        lower_bound= [-1, 1];
        upper_bound = [0, 2] ;
        dimensions=2; 
      case 'SYM_PART_simple'
        Fitness_Function = @MMF1;
        lower_bound= -20;
        upper_bound = 20 ;
        dimensions=2;  
       case 'MMF5'
        Fitness_Function = @MMF5;
        lower_bound= [1, 3];
        upper_bound = [-1, 3] ;
        dimensions=2;
        case 'MMF6'
        Fitness_Function = @MMF6;
        lower_bound= [1, 2];
        upper_bound = [-1, 2] ;
        dimensions=2;
         case 'MMF7'
        Fitness_Function = @MMF7;
        lower_bound= [1, 3];
        upper_bound = [-1, 1] ;
        dimensions=2;
        case 'MMF8'
        Fitness_Function = @MMF8;
        lower_bound= [-pi, pi];
        upper_bound = [0, 9] ;
        dimensions=2;
        case 'MMF9'
        Fitness_Function = @MMF9;
        lower_bound= [0.1, 1.1];
        upper_bound = [0.1 ,1.1 ] ;
        dimensions=2;
         case 'MMF10'
        Fitness_Function = @MMF10;
        lower_bound= [0.1, 1.1];
        upper_bound = [0.1 ,1.1 ] ;
        dimensions=2;
        case 'MMF11'
        Fitness_Function = @MMF11;
        lower_bound= [0.1, 1.1];
        upper_bound = [0.1 ,1.1 ] ;
        dimensions=2;
        case 'MMF12'
        Fitness_Function = @MMF12;
        lower_bound= [0,1];
        upper_bound = [0,1] ;
        dimensions=2;
end      



function  o=ZDT(x)

    n=numel(x);

    f1=x(1);
    
    g=1+9/(n-1)*sum(x(2:end));
    
    h=1-sqrt(f1/g);
    
    f2=g*h;
    
    o=[f1
       f2];
  

    % disp("o===");
    % disp(o);
    
    
     % Save the output in a file
%     fileID = fopen('zdt1.txt', 'a');  % Open the file in append mode
%     fprintf(fileID, '%f,%f\n', f1, f2);  % Write f1 and f2 to the file as "f1,f2"
%     fclose(fileID);
  
end
function z = ZTD2(x)

    n=numel(x);
    
    z1=1-exp(-sum((x-1/sqrt(n)).^2));
    
    z2=1-exp(-sum((x+1/sqrt(n)).^2));
    
    z=[z1 z2]';

end

function z = ZTD4(x)

    a=0.8;
    
    b=3;
    
    z1=sum(-10*exp(-0.2*sqrt(x(1:end-1).^2+x(2:end).^2)));
    
    z2=sum(abs(x).^a+5*(sin(x)).^b);
    
    z=[z1 z2]';

end



end
% function  [ z ] = ZDT3_n( x )
% %ZDT3 Summary of this function goes here
% %   Detailed explanation goes here
% n=numel(x);
% s = 0;
% for i= 2 :n
%     s= s + x(i);
% end
%     f1 = x(1);
%     gx = 1+(9/29)*(s);
%     h = 1-sqrt(f1/gx)-(f1/gx);
%     f2 = gx *h ;
% end