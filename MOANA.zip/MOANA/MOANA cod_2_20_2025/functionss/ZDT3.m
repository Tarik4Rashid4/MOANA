function [ z ] = ZDT3( x )
%ZDT3 Summary of this function goes here
%   Detailed explanation goes here
n=numel(x);
s = 0;
for i= 2 :n
    s= s + x(i);
end
    f1 = x(1);
    gx = 1+(9/29)*(s);
    h = 1-sqrt(f1/gx)-(f1/gx);
    f2 = gx *h ;
    
    z= [f1
        f2];

end

