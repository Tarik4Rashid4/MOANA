function [ z ] = ZDT2( x )
%ZDT3 Summary of this function goes here
%   Detailed explanation goes here
n=numel(x);

sum = 0;
for i= 2 :n
    sum= sum + x(i);
end
    f1 = x(1);
    gx = 1+ (9/n-1)*sum;
    h = 1-(f1/gx)^2;
    f2 = gx * h;
    
    z= [f1
        f2];

end

