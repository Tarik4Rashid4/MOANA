function [ z ] = ZDT4( x )

n=numel(x);
sum = 0;
for i= 2 :n
    sum= sum + (x(i)^2- 10*cos(4*pi*x(i)));
end

 f1 = x(1);
 gx= 1+ 10*(n-1)+ sum ;
 f2 = gx *(1- sqrt(f1/gx));
 z= [f1 
     f2];
end

