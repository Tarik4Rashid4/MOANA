function [ z ] = ZDT6( x )

n=numel(x);
sum = 0;
for i= 2 :n
    sum= sum + x(i);
end
 gx= 1+9*(sum/(n-1))^0.25;
 f1 = 1-exp(-4*x(1)) * sin(6*pi*x(1))^6;
 f2 = gx *(1- (f1/gx)^2);
 z= [f1  
     f2];
end

