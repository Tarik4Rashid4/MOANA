function [ z ] = ZDT1( x )
%ZDT3 Summary of this function goes here
%   Detailed explanation goes here
n=numel(x);
sum = 0;
for i= 2 :n
    sum= sum + x(i);
end
    f1 = x(1);
    gx= 1+ (9/(n-1))*sum;
    h= (1-sqrt(f1/gx));
    f2 = gx * h;
    
    z= [f1
        f2];

end

