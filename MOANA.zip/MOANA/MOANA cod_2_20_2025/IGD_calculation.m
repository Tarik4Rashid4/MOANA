
%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function  IGD=IGD_calculation(obtained_ps,reference_ps)
% IGD_calculation: Calculate the IGD of the obtained Pareto set
% Dimension: n_var --- dimensions of decision space

%% Input:
%                      Dimension                                                   Description
%      obtained_ps     population_size x n_var                                     Obtained Pareto set     
%      reference_ps    num_of_solutions_in_reference_ps x n_var                    Reference Pareto set

%% Output:
%                     Description
%      IGD            Inverted Generational Distance (IGD) of the obtained Pareto set

n_ref=size(reference_ps,1);

for i=1:n_ref
    ref_m=repmat(reference_ps(i,:),size(obtained_ps,1),1); 
    d=obtained_ps-ref_m;    %Calculate the the differences btween the obtained_ps and the reference_ps
    D=sum(abs(d).^2,2).^0.5;%Calculate the the distance btween the obtained_ps and the reference_ps
    obtained_to_ref(i)=min(D);
end
IGD=sum(obtained_to_ref)/n_ref;
end