%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function f = MMF3(x)
% 0<=x1<= 1  0<=x2<=1.5
   f=zeros(2,1);
    f(1)      = x(1);
y2 = x(2);
    if x(2)>=0&&x(2)<=0.5                       %0<=x(2)<=0.5
        y2=x(2)-x(1)^0.5;
    end
    if x(2)>0.5&&x(2)<1&&x(1)>=0&&x(1)<=0.25    %0.5<x(2)<1&&0<=x(1)<=0.25
        y2=x(2)-0.5-x(1)^0.5;
    end
    if x(2)>0.5&&x(2)<1&&x(1)>0.25              %0.5<x(2)<1&&x(1)>0.25
        y2=x(2)-x(1)^0.5;
    end
    if x(2)>=1&&x(2)<=1.5                             %1<=x(2)<=1.5           
        y2=x(2)-0.5-x(1)^0.5;
    end
   f(2)      = 1.0 - (x(1))^0.5 + 2*((4*y2^2)-2*cos(20*y2*pi/sqrt(2))+2);
end

% %% generate ture PS and true PF
% no=400;                  %���������Ž⼯�н�ĸ���
% PS(1:no/2,1)=linspace(0,1,no/2);
% PS(1:no/2,2)=sqrt(PS(1:no/2,1));
% PS(no/2+1:no,1)=linspace(0,1,no/2);
% PS(no/2+1:no,2)=PS(1:no/2,2)+0.5;
% 
% PF(:,1)     = linspace(0,1,no/2);
% PF(:,2)     = 1-sqrt(PF(:,1));
% figure(1)
% plot(PS(:,1),PS(:,2),'ro');
% figure(2)
% plot(PF(:,1),PF(:,2),'ro');


