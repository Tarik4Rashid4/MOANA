
%{
% MOANA Algorthim
% cite as 
%  Rashed, Noor A. T. Rashid, et al. "MOANA: Multi-objective ant nesting algorithm for optimization problems",
% DOI: 10.1016/j.heliyon.2024.e40087 


Hama Rashid, D. N.; Rashid, T.A.; Mirjalili, S. ANA: Ant Nesting Algorithm for Optimizing Real-World Problems. Mathematics 2021, 9, 3111. https://doi.org/10.3390/math9233111

J. M. Abdullah and T. A. Rashid (2019). Fitness Dependent Optimizer: Inspired by the Bee Swarming Reproductive Process," in IEEE Access, vol. 7, pp. 43473-43486. DOI:https://doi.org/10.1109/ACCESS.2019.2907012

%}
function swarm = initialize_swarm(swarm_size)
    % Initialize an empty array to store particles
    swarm = struct('position', [], 'velocity', [], 'personal_best', []);

    for i = 1:swarm_size
        % Generate a random initial position for each dimension
        position = rand(); % You can customize this based on your problem

        % Initialize velocity to zero
        velocity = 0;

        % Initialize personal best to the current position
        personal_best = position;

        % Create a particle structure and add it to the swarm
        particle = struct('position', position, 'velocity', velocity, 'personal_best', personal_best);
        swarm(i) = particle;
    end
end
